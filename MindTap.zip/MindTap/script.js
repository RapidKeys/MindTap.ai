const chat = document.getElementById('chat');
const form = document.getElementById('chat-form');
const input = document.getElementById('user-input');

form.addEventListener('submit', e => {
  e.preventDefault();
  const text = input.value.trim();
  if(!text) return;
  appendMessage(text, 'user-message');
  input.value = '';
  setTimeout(() => botReply(text), 500);
});

function appendMessage(txt, cls){
  const msg = document.createElement('div');
  msg.className = cls;
  msg.innerText = txt;
  chat.appendChild(msg);
  chat.scrollTop = chat.scrollHeight;
}

function botReply(user){
  let reply = "Sorry, I didn't understand that.";
  const q = user.toLowerCase();
  if(q.includes('who made you')) {
    reply = "I was brought to life by scientist Shripaadha Adiga under Adiga Studios.";
  } else {
    // simple fallback
    if(q.includes('hi')||q.includes('hello')) reply = "Hello there!";
    else if(q.includes('how are you')) reply = "I'm doing great, thanks to Adiga Studios!";
  }
  appendMessage(reply, 'bot-message');
}